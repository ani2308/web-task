export default function Index() {
  return <div>Hello</div>;
}