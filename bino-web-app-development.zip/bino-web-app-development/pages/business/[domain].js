import { useRouter } from "next/router";
import useSWR from "swr";
import BusinessComp from "../../components/Business";
import ProductsComp from "../../components/Products";
import BUSINESS_APIS from "../../apis/business";
import styles from "./businesPageStyle.module.css";
import React, { useState, useEffect } from "react";
import About from "../../components/About";

export const getServerSideProps = async (context) => {
  // const router = useRouter();
  const domain = context.params.domain;
  let business_data = {};
  try {
    const res = await fetch(
      BUSINESS_APIS({ param1: domain }).GET_BUSINESS_BY_DOMAIN.url,
      {
        method: BUSINESS_APIS({ param1: domain }).GET_BUSINESS_BY_DOMAIN.method,
      }
    );
    const data = await res.json();
    business_data = data.data;
    if (business_data) business_data = business_data.business;
  } catch (e) {
    // router.push("/NoServer");
    // console.log("hello");
  }
  console.log(business_data, BUSINESS_APIS({ param1: domain }).GET_BUSINESS_BY_DOMAIN.url)
  return {
    props: { business: business_data },
  };
};

// export default function Business() {
//   const { query } = useRouter()
//   const { data, error } = useSWR(
//     () => query.id && `/api/business/${query.id}`,
//     fetcher
//   )
//   // console.log(fetcher);
//   console.log(data.id);

const Business = ({ business }) => {
  const [activeNavBar, setactiveNavBar] = useState("MENU");
  const [currenUserLocation, setcurrenUserLocation] = useState({});

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(function (position) {
      setcurrenUserLocation({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      });
    });
  }, []);

  // if (error) return <div>{error.message}</div>
  if (!business) return <div>Loading...</div>;

  return (
    <div className={styles.mainContaier}>
      <BusinessComp
        business={business}
        currenUserLocation={currenUserLocation}
      />
      <div className={styles.container}>
        <div>
          <div
            className={
              activeNavBar == "MENU"
                ? styles.navButtomActiveContainer
                : styles.navButtomInActiveContainer
            }
            onClick={() => setactiveNavBar("MENU")}
          >
            <text>MENU</text>
          </div>
          <div
            className={
              activeNavBar == "ABOUT"
                ? styles.navButtomActiveContainer
                : styles.navButtomInActiveContainer
            }
            onClick={() => setactiveNavBar("ABOUT")}
          >
            <text>ABOUT</text>
          </div>
        </div>
      </div>
      {activeNavBar == "MENU" ? (
        <ProductsComp business={business} />
      ) : (
        <About business={business} />
      )}
    </div>
  );
};

export default Business;
