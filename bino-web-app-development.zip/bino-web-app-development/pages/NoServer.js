import React from "react";

const NoServer = () => {
  return <div>NoServer</div>;
};

export default NoServer;
