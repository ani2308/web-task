let html = require('../templates/index.html.js');
export default function Index() {
  return <div dangerouslySetInnerHTML={{__html:html}}/>;
}
