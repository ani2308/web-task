/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config, options) => {
    config.module.rules.push({
      test: /\.html$/i,
      loader: 'html-loader',
    })

    return config
  },
  reactStrictMode: true,
  swcMinify: true,
  output: 'standalone',
  images: {
    domains: [
      "images.pexels.com",
      "www.tutorialspoint.com",
      "tredr-uploads-staging.s3.ap-south-1.amazonaws.com",
        "tredr-public-static.s3.ap-south-1.amazonaws.com"
    ],
  },
};

module.exports = nextConfig;
