const CREDENCE_BASE = process.env.NEXT_PUBLIC_CREDENCE_URL;
const TREDR_BASE = process.env.NEXT_PUBLIC_TREDR_BASE;
const apis = (api_params) => {
  let all_apis = {
    GET_BUSINESS_BY_DOMAIN: {
      url: `${TREDR_BASE}/v1/business/by-domain/${api_params.param1}`,
      method: "GET",
    },
    GET_PRODUCTS_FOR_BUSINESS: {
      url: `${TREDR_BASE}/v1/business/get-products/${api_params.param1}`,
      method: "GET",
    },
  };
  return all_apis;
};
module.exports = apis;
