module.exports = `<html lang="en">
<head>
  <title>Boni</title>
<!--  <link rel="icon" href="./public/favicon.ico" type="image/icon type">-->
  <meta property="og:title" content="Boni" />
  <meta name="keywords" content="Boni, bino, platforms near me, best businnes near me, register local businees online,all in one busines app"/>
  <meta name="description" content="List your business, get discovered and engage better with customers"/>
  <meta property="twitter:card" content="summary_large_image" />
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta charset="utf-8" />
  <meta property="twitter:card" content="summary_large_image" />
  <style>
    html {  line-height: 1.15;}body {  margin: 0;}* {  box-sizing: border-box;  border-width: 0;  border-style: solid;}p,li,ul,pre,div,h1,h2,h3,h4,h5,h6 {  margin: 0;  padding: 0;}button,input,optgroup,select,textarea {  font-family: inherit;  font-size: 100%;  line-height: 1.15;  margin: 0;}button,select {  text-transform: none;}button,[type="button"],[type="reset"],[type="submit"] {  -webkit-appearance: button;}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner {  border-style: none;  padding: 0;}button:-moz-focus,[type="button"]:-moz-focus,[type="reset"]:-moz-focus,[type="submit"]:-moz-focus {  outline: 1px dotted ButtonText;}a {  color: inherit;  text-decoration: inherit;}input {  padding: 2px 4px;}img {  display: block;}
  </style>
  <style>
    html {
      font-family: Raleway;
      font-size: 18px;
    }

    body {
      font-weight: 400;
      font-style:normal;
      text-decoration: none;
      text-transform: none;
      letter-spacing: normal;
      line-height: 1.55;
      color: var(--dl-color-gray-black);
      background-color: var(--dl-color-gray-white);

    }
  </style>
      <link rel="stylesheet" href="/assets/css2">
    <link rel="stylesheet" href="/assets/css2(1)">
  <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
  />
  <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
  />
  <style>
    html {
      scroll-behavior: smooth;
    }
  </style>
  <link rel="stylesheet" href="/assets/style.css" />
</head>
<body>
<div>
  <link href="/assets/home.css" rel="stylesheet" />

  <div class="home-container">
    <div data-role="Header" class="home-navbar-container">
      <div class="home-navbar">
        <div class="home-left-side">
          <img
                  alt="image"
                  src="/assets/icon-192.png"
                  class="home-image"
          />
          <div data-type="BurgerMenu" class="home-burger-menu">
            <svg viewBox="0 0 1024 1024" class="home-icon">
              <path
                      d="M128 256h768v86h-768v-86zM128 554v-84h768v84h-768zM128 768v-86h768v86h-768z"
              ></path>
            </svg>
          </div>
          <div class="home-links-container">
            <a href="#resources" class="home-link anchor">Why Boni</a>
            <a href="#inspiration" class="home-link1 anchor">Partners</a>
            <a href="#process" class="home-link2 anchor">Contact</a>
            <!-- <a href="privacypolicy.html" class="home-link2 anchor">Privacy Policies</a> -->
          </div>
        </div>
        <div class="home-right-side">
          <button class="home-cta-btn anchor button" id="downloadapp">Download Our App</button>
        </div>
        <div data-type="MobileMenu" class="home-mobile-menu">
          <div class="home-container1">
            <img
                    alt="image"
                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                    class="home-image1"
            />
            <div data-type="CloseMobileMenu" class="home-close-menu">
              <svg viewBox="0 0 1024 1024" class="home-icon02">
                <path
                        d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"
                ></path>
              </svg>
            </div>
          </div>
          <div class="home-links-container1">
            <a href="#resources" class="home-link3 anchor">Resources</a>
            <a href="#inspiration" class="home-link4 anchor">Inspiration</a>
            <a href="#process" class="home-link5 anchor">Process</a>
            <span class="home-link6 anchor">Our story</span>
          </div>
        </div>
      </div>
    </div>
    <div id="resources" class="home-hero">
      <div class="home-content-container">
        <div class="home-hero-text">
          <h1 class="home-heading section-Heading">
            Connect with Customers and Grow your Business
          </h1>
          <span class="home-text section-Text">
                <span>
                  Boni is a platform for small local businesses to digitally
                  manage their business starting from getting discovered,
                  marketing and engaging better with customers around them
                </span>
                <span>&amp;#8203;</span>
              </span>
          <button class="home-cta-btn1 anchor button" id="downloadapp">Download Our App</button>
        </div>
      </div>
    </div>
    <div class="home-section-separator"></div>
    <div id="inspiration" class="home-features">
      <div class="home-heading-container">
        <h2 class="home-text03 section-Heading">Who is Boni for?</h2>
      </div>
      <img
              alt="image"
              src="assets/whyboni.png"
              class="home-image2"
      />
      <h1 class="home-text04">
        <span>There&apos;s over 50 million small local businesses</span>
        <br />
        <span>serving customers in their neighborhoods.</span>
        <br />
        <span>Our mission is to double their income.</span>
      </h1>
    </div>
    <div class="home-section-separator1"></div>
    <div id="inspiration" class="home-features1">
      <div class="home-heading-container1">
        <h2 class="home-text10 section-Heading">Why Boni</h2>
      </div>
      <div class="home-cards-container">
        <div class="home-features-card">
          <div class="home-icon-container">
            <svg viewBox="0 0 1024 1024" class="home-icon04">
              <path
                      d="M446 598l280-282-60-60-220 222-88-90-60 60zM512 86q124 0 211 87t87 211q0 62-31 142t-75 150-87 131-73 97l-32 34q-12-14-32-37t-72-92-91-134-71-147-32-144q0-124 87-211t211-87z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container">
            <span class="home-heading1 card-Heading">Get found</span>
            <span class="home-text11 card-Text">
                  Get found by customers near you.
                </span>
          </div>
        </div>
        <div class="home-features-card1">
          <div class="home-icon-container1">
            <svg viewBox="0 0 1024 1024" class="home-icon06">
              <path
                      d="M512 768v-128l170 170-170 172v-128q-140 0-241-101t-101-241q0-100 54-182l62 62q-30 54-30 120 0 106 75 181t181 75zM512 170q140 0 241 101t101 241q0 100-54 182l-62-62q30-54 30-120 0-106-75-181t-181-75v128l-170-170 170-172v128z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container1">
            <span class="home-heading2 card-Heading">Engage better</span>
            <span class="home-text12 card-Text">
                  Engage better with your existing customers, leading to more
                  retention and repeat purchases
                </span>
          </div>
        </div>
        <div class="home-features-card2">
          <div class="home-icon-container2">
            <svg viewBox="0 0 1024 1024" class="home-icon08">
              <path
                      d="M1024 429.256c0-200.926-58.792-363.938-131.482-365.226 0.292-0.006 0.578-0.030 0.872-0.030h-82.942c0 0-194.8 146.336-475.23 203.754-8.56 45.292-14.030 99.274-14.030 161.502s5.466 116.208 14.030 161.5c280.428 57.418 475.23 203.756 475.23 203.756h82.942c-0.292 0-0.578-0.024-0.872-0.032 72.696-1.288 131.482-164.298 131.482-365.224zM864.824 739.252c-9.382 0-19.532-9.742-24.746-15.548-12.63-14.064-24.792-35.96-35.188-63.328-23.256-61.232-36.066-143.31-36.066-231.124 0-87.81 12.81-169.89 36.066-231.122 10.394-27.368 22.562-49.266 35.188-63.328 5.214-5.812 15.364-15.552 24.746-15.552 9.38 0 19.536 9.744 24.744 15.552 12.634 14.064 24.796 35.958 35.188 63.328 23.258 61.23 36.068 143.312 36.068 231.122 0 87.804-12.81 169.888-36.068 231.124-10.39 27.368-22.562 49.264-35.188 63.328-5.208 5.806-15.36 15.548-24.744 15.548zM251.812 429.256c0-51.95 3.81-102.43 11.052-149.094-47.372 6.554-88.942 10.324-140.34 10.324-67.058 0-67.058 0-67.058 0l-55.466 94.686v88.17l55.46 94.686c0 0 0 0 67.060 0 51.398 0 92.968 3.774 140.34 10.324-7.236-46.664-11.048-97.146-11.048-149.096zM368.15 642.172l-127.998-24.51 81.842 321.544c4.236 16.634 20.744 25.038 36.686 18.654l118.556-47.452c15.944-6.376 22.328-23.964 14.196-39.084l-123.282-229.152zM864.824 548.73c-3.618 0-7.528-3.754-9.538-5.992-4.87-5.42-9.556-13.86-13.562-24.408-8.962-23.6-13.9-55.234-13.9-89.078s4.938-65.478 13.9-89.078c4.006-10.548 8.696-18.988 13.562-24.408 2.010-2.24 5.92-5.994 9.538-5.994 3.616 0 7.53 3.756 9.538 5.994 4.87 5.42 9.556 13.858 13.56 24.408 8.964 23.598 13.902 55.234 13.902 89.078 0 33.842-4.938 65.478-13.902 89.078-4.004 10.548-8.696 18.988-13.56 24.408-2.008 2.238-5.92 5.992-9.538 5.992z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container2">
            <span class="home-heading3 card-Heading">Market yourself</span>
            <span class="home-text13 card-Text">
                  Send updates and offers to attract new customers and gain
                  visibility
                </span>
          </div>
        </div>
        <div class="home-features-card3">
          <div class="home-icon-container3">
            <svg viewBox="0 0 1024 1024" class="home-icon10">
              <path
                      d="M854 256q36 0 60 25t24 61v468q0 36-24 61t-60 25h-684q-36 0-60-25t-24-61v-468q0-36 24-61t60-25h172v-86q0-36 24-60t60-24h172q36 0 60 24t24 60v86h172zM170 342v468h684v-468h-684zM598 256v-86h-172v86h172z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container3">
            <span class="home-heading4 card-Heading">Digital tools</span>
            <span class="home-text14 card-Text">
                  Digital tools to manage your business better
                </span>
          </div>
        </div>
        <div class="home-features-card4">
          <div class="home-icon-container4">
            <svg viewBox="0 0 1024 1024" class="home-icon12">
              <path
                      d="M170 470h684v84h-684v-84zM682 214l-170 170-170-170h128v-172h84v172h128zM342 810l170-170 170 170h-128v172h-84v-172h-128z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container4">
            <span class="home-heading5 card-Heading">Optimize costs</span>
            <span class="home-text15 card-Text">
                  Improve inventory and supply chain and save costs
                </span>
          </div>
        </div>
        <div class="home-features-card5">
          <div class="home-icon-container5">
            <svg viewBox="0 0 1097.142857142857 1024" class="home-icon14">
              <path
                      d="M438.857 658.286h219.429v-54.857h-73.143v-256h-65.143l-84.571 78.286 44 45.714c13.714-12 22.286-18.286 31.429-32.571h1.143v164.571h-73.143v54.857zM731.429 512c0 104-62.857 237.714-182.857 237.714s-182.857-133.714-182.857-237.714 62.857-237.714 182.857-237.714 182.857 133.714 182.857 237.714zM1024 658.286v-292.571c-80.571 0-146.286-65.714-146.286-146.286h-658.286c0 80.571-65.714 146.286-146.286 146.286v292.571c80.571 0 146.286 65.714 146.286 146.286h658.286c0-80.571 65.714-146.286 146.286-146.286zM1097.143 182.857v658.286c0 20-16.571 36.571-36.571 36.571h-1024c-20 0-36.571-16.571-36.571-36.571v-658.286c0-20 16.571-36.571 36.571-36.571h1024c20 0 36.571 16.571 36.571 36.571z"
              ></path>
            </svg>
          </div>
          <div class="home-text-container5">
            <span class="home-heading6 card-Heading">Access to credit</span>
            <span class="home-text16 card-Text">
                  Access financial services like credit based on how your
                  business does
                </span>
          </div>
        </div>
      </div>
    </div>
    <div class="home-section-separator2"></div>
    <div id="process" class="home-services">
      <div class="home-heading-container2">
        <h1 class="home-text17 section-Heading">Partners</h1>
      </div>
      <div class="home-cards-container1">
        <img
                src="/assets/download-300h.png"
                alt="image"
                class="home-image3"
        />
      </div>
    </div>
    <div class="home-section-separator3"></div>
    <div class="home-get-in-touch">
      <h2 class="home-text18 section-Heading">Get in touch</h2>
      <div class="home-content-container1">
        <div class="home-form-container">
              <span class="home-heading7 bigCard-Heading">
                Send us a message
              </span>
          <input
                  type="text"
                  required="true"
                  placeholder="Name"
                  class="home-name input"
          />
          <input
                  type="text"
                  required="true"
                  placeholder="E-mail"
                  class="home-email input"
          />
          <textarea
                  placeholder="Your Message"
                  class="home-message textarea"
          ></textarea>
          <button class="home-cta-btn2 anchor button">SEND</button>
        </div>
      </div>
    </div>
    <div class="home-section-separator4"></div>
    <div class="home-footer-container">
      <div class="home-footer">
        <div class="home-copyright-container">
          <svg viewBox="0 0 1024 1024" class="home-icon16">
            <path
                    d="M512 854q140 0 241-101t101-241-101-241-241-101-241 101-101 241 101 241 241 101zM512 86q176 0 301 125t125 301-125 301-301 125-301-125-125-301 125-301 301-125zM506 390q-80 0-80 116v12q0 116 80 116 30 0 50-17t20-43h76q0 50-44 88-42 36-102 36-80 0-122-48t-42-132v-12q0-82 40-128 48-54 124-54 66 0 104 38 42 42 42 98h-76q0-14-6-26-10-20-14-24-20-20-50-20z"
            ></path>
          </svg>
          <span class="anchor">Bohni Tech Pvt Ltd 2022</span>


        </div>
      </div>
<!--
      <a href="privacypolicy.html" class="home-link2 anchor">Privacy Policies</a>
-->
    </div>
  </div>
</div>

<script src="https://unpkg.com/@teleporthq/teleport-custom-scripts"></script>
<script type="text/javascript">
  document.getElementById("downloadapp").onclick = function () {
    location.href = "https://play.google.com/store/apps/details?id=com.bonitech.boni";
  };
</script>
</body>
</html>`
