const LocationSvg = () => {
  return (
    <svg
      width="13"
      height="21"
      viewBox="0 0 13 21"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <ellipse
        cx="6.50001"
        cy="18.7778"
        rx="6.50001"
        ry="1.44445"
        fill="#CAC5FF"
      />
      <circle cx="6.50001" cy="6.50001" r="6.50001" fill="#6A5BFF" />
      <rect
        x="5.77777"
        y="11.9844"
        width="1.44445"
        height="7.22223"
        rx="0.722223"
        fill="#6A5BFF"
      />
    </svg>
  );
};

export default LocationSvg;
