import React from "react";
import styles from "./about.module.css";
import AboutLocationSvg from "./SVG/AboutLocationSvg";
import { myNavFunc } from "../apis/Utls";

const About = ({ business }) => {
  return (
    <div className={styles.container}>
      <div>
        <text>About </text>
        <p>{business.description}</p>
        <text>Contact</text>
        <div className={styles.addressInfoContainer}>
          <div className={styles.addressInfoLift}>
            <AboutLocationSvg />
            <text>{business.full_address}</text>
          </div>
          <div
            className={styles.addressInfoRight}
            onClick={() => myNavFunc(business.lat, business.long)}
          >
            <text>Map</text>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
