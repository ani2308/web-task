import Link from "next/link";
import React, { useState, useEffect } from "react";
import BUSINESS_APIS from "../apis/business";
import styles from "./products.module.css";
import NoImageSvg from "./SVG/NoImageSvg";
import SearchSvg from "./SVG/SearchSvg";
import Image from "next/image";

export default function Product({ business }) {
  const [data, setData] = useState(null);
  const [listData, setlistData] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [searchText, setsearchText] = useState("");

  const searchData = (event) => {
    let text = event.target.value;
    setsearchText(text);
    setlistData(
      data.products.filter((item) => item.name.toLowerCase().includes(text))
    );
  };

  useEffect(() => {
    setLoading(true);
    (async () => {
      try {
        const res = await fetch(
          BUSINESS_APIS({ param1: business.id }).GET_PRODUCTS_FOR_BUSINESS.url,
          {
            method: BUSINESS_APIS({}).GET_PRODUCTS_FOR_BUSINESS.method,
          }
        );
        const data = await res.json();
        if (data.data && data.success) {
          // console.log(data.data);
          setlistData(data.data.products);
          setData(data.data);
          setLoading(false);
        }
      } catch (e) {
        console.log(e);
        setData(null);
        setlistData(null);
      }
    })();
  }, []);
  if (isLoading) return <p>Loading...</p>;
  if (!listData) return <p>No profile data</p>;

  return (
    <div className={styles.container}>
      <div>
        <div className={styles.searchBar}>
          <input
            placeholder="Search for Products or Services"
            value={searchText}
            onChange={searchData}
          />
          <SearchSvg />
        </div>
        {listData.map((e, index) => (
          <div className={styles.listContainer} key={index}>
            <div className={styles.subListContainer}>
              <div>
                <Image src={e.photos[0]} width={"100%"} height={"100%"} />
              </div>
              <text className={styles.productName}>{e.name}</text>
              <text className={styles.productPrice}>
                ₹{e.selling_price}/{e.price_unit}
              </text>
            </div>
            <div className={styles.lineDiv}></div>
          </div>
        ))}
      </div>
    </div>
  );
}
