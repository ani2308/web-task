import Link from "next/link";
import Image from "next/image";
import styles from "./business.module.css";
import OpenSvg from "./SVG/OpenSvg";
import LocationSvg from "./SVG/LocationSvg";
import CloseSvg from "./SVG/CloseSvg";
import MapSvg from "./SVG/MapSvg";
import { getDistance } from "geolib";
import { myNavFunc } from "../apis/Utls";

export default function Business({ business, currenUserLocation }) {
  return (
    <div className={styles.container}>
      <div className={styles.businessInfoContainer}>
        <div className={styles.businessImage}>
          <Image src={business.thumbnail} width={256} height={256} />
        </div>
        <div>
          <h2 className={styles.titleName}>{business.business_name}</h2>
          <div className={styles.statusContainer}>
            <div>
              {business.BusinessStatus.shop_status == "open" ? (
                <OpenSvg />
              ) : (
                <CloseSvg />
              )}
              <t>{business.BusinessStatus.shop_status}</t>
            </div>
            <div>
              <LocationSvg />
              <t>
                {getDistance(currenUserLocation, {
                  latitude: business.lat,
                  longitude: business.long,
                }) / 1000}{" "}
                km
              </t>
            </div>
            <div onClick={() => myNavFunc(business.lat, business.long)}>
              <MapSvg />
              <t>View on map</t>
            </div>
          </div>
          <div className={styles.catStyles}>
            {business.BusinessCategories.map((e, index) => (
              <div key={index}>
                <text>{e.name}</text>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className={styles.shareIcon}>{/* <ShareIconSvg /> */}</div>
    </div>
  );
}
